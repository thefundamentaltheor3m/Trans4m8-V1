#! /bin/bash
python3 -m venv ./venv
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
brew install cairo
brew install ffmpeg
brew install sox
brew install mactex
eval "$(/usr/libexec/path_helper)"
./venv/bin/pip3 install -r ./requirements.txt
chmod a+x ./Trans4m8.sh