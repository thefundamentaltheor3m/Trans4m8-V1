from GUI_Design_V12 import Session
import os, glob, shutil

if __name__=='__main__':
    abspath = os.path.abspath(__file__)
    dname = os.path.dirname(abspath) + "/BackendFiles"
    os.chdir(dname)

    print("PRESENT WORKING DIRECTORY:")
    print(os.getcwd())
    print("PYTHON COMPILER:")
    os.system("which python3.8")

    print("Configuring default startup files...")
    default_files = glob.iglob(os.path.join(dname + "/Default", "*.*"))
    for file in default_files:
        if os.path.isfile(file):
            print("Copying" + str(file))
            shutil.copy2(file, dname)
    print("Done")

    print("====================\nWelcome to Trans4m8!\n====================")

    run = Session()

    print("Program Terminated. Clearing runtime files:")

    # Following code modified from https://stackoverflow.com/questions/296173/how-do-i-copy-files-with-specific-file-extension-to-a-folder-in-my-python-versi

    files_tex = glob.iglob(os.path.join(dname, "*.tex"))
    for file in files_tex:
        if os.path.isfile(file):
            os.remove(file)
    print("*.tex cleaned up")

    files_aux = glob.iglob(os.path.join(dname, "*.aux"))
    for file in files_aux:
        if os.path.isfile(file):
            os.remove(file)
    print("*.aux cleaned up")

    files_svg = glob.iglob(os.path.join(dname, "*.svg"))
    for file in files_svg:
        if os.path.isfile(file):
            os.remove(file)
    print("*.svg cleaned up")

    files_dvi = glob.iglob(os.path.join(dname, "*.dvi"))
    for file in files_dvi:
        if os.path.isfile(file):
            os.remove(file)
    print("*.dvi cleaned up")

    files_log = glob.iglob(os.path.join(dname, "*.log"))
    for file in files_log:
        if os.path.isfile(file):
            os.remove(file)
    print("*.log cleaned up")

    print("Done")