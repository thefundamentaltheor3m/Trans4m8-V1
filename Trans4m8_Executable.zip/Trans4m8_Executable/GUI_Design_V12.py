"""
This file contains the entire program in the form of a class, called Session.
To run, simply type

exampleSession = Session()

And that should do it!
"""

#  With working Reference Points

from tkinter import *
from tkinter import messagebox  # For some reason you need to import it again...

from tkinter import ttk
from ttkthemes import ThemedTk

from PIL import Image, ImageTk  # ImageTk returns a tkinter image widget thingy
from FunctionGraph_V5 import *

print("LIBRARY PATHS:")

print(manimlib.__file__)
print(sp.__file__)
print(ne.__file__)
print(ttk.__file__)


class Session:

    def __init__(self):

        self.root = ThemedTk(theme="ubuntu")  # adapta is also pretty good
        self.root.minsize(1200, 700)
        self.root.maxsize(1920, 1080)  # Sizes obtained from Microsoft Developer
        # [client uses Windows but I use Mac]
        self.root.title('Trans4m8')

        self.resize_amount = 0.40  # For all images

        """ PRIMARY INPUT: """

        entry_label = ttk.Label(self.root, text='f(x) = ')
        entry_label.config()
        entry_label.grid(row=0, columnspan=10, sticky=E)

        self.function_entry = ttk.Entry(self.root, width=62)
        self.function_entry.insert(index=0, string="To get started, enter a function...")
        self.function_entry.config()
        self.function_entry.grid(row=0, column=10, columnspan=14)

        self.graph_it = ttk.Button(self.root, text='GRAPH IT!', command=self.graphIt)
        self.graph_it.config()
        self.graph_it.grid(row=1, columnspan=28)

        """ STARTUP CONFIGURATION: """

        self.original = "sin(x)"
        self.inputFunction = self.original
        self.x = 'x'
        self.y = 'y'
        self.ref_x = [np.pi/2, None, None, None, None, None, None, None, None, None]
        self.ref_y = [1, None, None, None, None, None, None, None, None, None]

        obj = FunctionGraph(
            original=self.original,
            f_of_x=self.inputFunction,
            x=self.x,
            y=self.y,
            x_min=-5.0,
            x_max=5.0,
            y_min=-5.0,
            y_max=5.0,
            ref_x=self.ref_x,
            ref_y=self.ref_y
        )
        img = obj.get_image()
        img = img.resize(
            (int(img.size[0] * self.resize_amount * self.root.winfo_width()),
             int(img.size[1] * self.resize_amount * self.root.winfo_height()))
        )  # The tuple must be (int, int)
        initialImage = ImageTk.PhotoImage(image=img)

        self.graphLabel = ttk.Label(self.root, image=initialImage)  # The label for the image
        self.graphLabel.grid(row=2, column=16, columnspan=14, rowspan=20, sticky=N + S + E + W)

        """ GRAPH PARAMETERS: """

        parameters = ttk.Frame(
            master=self.root,
            height=900,  # Depends on the widgets
            width=500,  # Depends on the widgets
            borderwidth=5,
            relief=SUNKEN,
            takefocus=True  # Users can use \tab\ to navigate.
        )
        parameters.grid(row=2, rowspan=3, columnspan=11)

        x_graph_stuff = ttk.Frame(master=parameters, takefocus=True)
        x_graph_stuff.grid(row=0, column=0, columnspan=2)

        y_graph_stuff = ttk.Frame(master=parameters, takefocus=True)
        y_graph_stuff.grid(row=0, column=3, columnspan=2)

        label_x_min = ttk.Label(x_graph_stuff, text='Min. x = ')
        label_x_min.config()
        label_x_min.grid(row=0, column=0)

        label_x_max = ttk.Label(x_graph_stuff, text='Max. x = ')
        label_x_max.config()
        label_x_max.grid(row=1, column=0)

        label_y_min = ttk.Label(y_graph_stuff, text='Min. y = ')
        label_y_min.config()
        label_y_min.grid(row=0, column=0)

        label_y_max = ttk.Label(y_graph_stuff, text='Max. y = ')
        label_y_max.config()
        label_y_max.grid(row=1, column=0)

        self.entry_x_min = ttk.Entry(x_graph_stuff, width=4)
        self.entry_x_min.config()
        self.entry_x_min.grid(row=0, column=1)

        self.entry_x_max = ttk.Entry(x_graph_stuff, width=4)
        self.entry_x_max.config()
        self.entry_x_max.grid(row=1, column=1)

        self.entry_y_min = ttk.Entry(y_graph_stuff, width=4)
        self.entry_y_min.config()
        self.entry_y_min.grid(row=0, column=1)

        self.entry_y_max = ttk.Entry(y_graph_stuff, width=4)
        self.entry_y_max.config()
        self.entry_y_max.grid(row=1, column=1)

        apply_parameters = ttk.Button(parameters, text='APPLY', command=self.modifyGraphParameters)
        apply_parameters.config()
        apply_parameters.grid(row=2, columnspan=5)

        """ TRANSFORMATION PARAMETERS: """

        transformation_pane = ttk.Frame(
            master=self.root,
            height=900,
            width=500,
            borderwidth=5,
            relief=SUNKEN,
            takefocus=True  # Users can use \tab\ to navigate.
        )
        transformation_pane.grid(row=5, rowspan=4, columnspan=11)

        list_of_options = [
            'Select transformation option:',
            '1 - Horizontal Scale',
            '2 - Horizontal Translation',
            '3 - Vertical Scale',
            '4 - Vertical Translation'
        ]

        self.placeholderText = StringVar(transformation_pane)
        self.placeholderText.set(list_of_options[0])

        self.options = ttk.OptionMenu(transformation_pane, self.placeholderText, *list_of_options)
        self.options.config(width=27, )
        self.options.grid(row=0, column=0, columnspan=3)

        # self.placeholderText.trace("w", self.transformIt)

        by_label = ttk.Label(transformation_pane, text='by')
        by_label.config()
        by_label.grid(row=1, column=0)

        self.transformation_parameter = ttk.Entry(transformation_pane, width=20)
        self.transformation_parameter.config()
        self.transformation_parameter.grid(row=1, column=1, columnspan=2)

        apply_transformation = ttk.Button(transformation_pane, text='TRANSFORM IT!', command=self.transformIt)
        apply_transformation.config()
        apply_transformation.grid(row=2, columnspan=3)

        """ REFERENCE POINTS: """

        referenceframe = ttk.Frame(
            master=self.root,
            height=900,  # Depends on the widgets
            width=500,  # Depends on the widgets
            borderwidth=5,
            relief=SUNKEN,
            takefocus=True  # Users can use \tab\ to navigate.
        )
        referenceframe.grid(row=9, rowspan=12, columnspan=11)

        refpts_labels = {  # Static behaviour necessary so that users can overwrite points and thereby delete them
            'x' : [None, None, None, None, None, None, None, None, None, None],
            'y' : [None, None, None, None, None, None, None, None, None, None]
        }

        self.refpts_entries = {
            'x': [None, None, None, None, None, None, None, None, None, None],
            'y': [None, None, None, None, None, None, None, None, None, None]
        }

        for i in range(0,10):
            refpts_labels['x'][i] = ttk.Label(referenceframe, text='x' + str(i+1) + ' = ')
            refpts_labels['x'][i].config()
            refpts_labels['x'][i].grid(row=i, column=0)

            self.refpts_entries['x'][i] = ttk.Entry(referenceframe, width=4)
            self.refpts_entries['x'][i].config()
            self.refpts_entries['x'][i].grid(row=i, column=1)

            refpts_labels['y'][i] = ttk.Label(referenceframe, text='y' + str(i + 1) + ' = ')
            refpts_labels['y'][i].config()
            refpts_labels['y'][i].grid(row=i, column=2)

            self.refpts_entries['y'][i] = ttk.Entry(referenceframe, width=4)
            self.refpts_entries['y'][i].config()
            self.refpts_entries['y'][i].grid(row=i, column=3)

        apply_refpts = ttk.Button(referenceframe, text='ADD POINTS', command=self.addRefPts)
        apply_refpts.config()
        apply_refpts.grid(row=10, columnspan=5)

        clear_refpts = ttk.Button(referenceframe, text='CLEAR POINTS', command=self.clearRefPts)
        clear_refpts.config()
        clear_refpts.grid(row=11, columnspan=5)

        """ UNDO AND REDO: """

        undo_redo_pane = ttk.Frame(
            master=self.root,
            borderwidth=5,
            relief=SUNKEN,
            takefocus=True  # Users can use \tab\ to navigate.
        )
        undo_redo_pane.grid(row=21, columnspan=11)

        undo_button = ttk.Button(undo_redo_pane, text='PREVIOUS', command=self.undo)
        undo_button.config()
        undo_button.pack()

        redo_button = ttk.Button(undo_redo_pane, text='NEXT', command=self.redo)
        redo_button.config()
        redo_button.pack()

        self.locationPlaceholderText = "Graph 0 of 0"
        self.location = ttk.Label(undo_redo_pane, text=self.locationPlaceholderText)
        self.location.config()
        self.location.pack()

        """ INSTANCE VARIABLES: """

        self.x = 'x'
        self.y = 'y'

        self.renderings = []  # PIL Image list
        self.transformationNumber = 0  # Transformation number--which-th iteration is it?

        self.functionList = []
        self.xList = []
        self.yList = []
        self.refxlist = []
        self.refylist = []

        """ FINISHING TOUCHES: """

        menubar = Menu(self.root)
        t4m8 = Menu(menubar)
        menubar.add_cascade(label='Trans4m8', menu=t4m8)
        t4m8.add_command(label='Help', command=self.help)
        t4m8.add_command(label='About...', command=self.about)
        t4m8.add_separator()
        t4m8.add_command(label='Previous Graph', command=self.undo)
        t4m8.add_command(label='Next Graph', command=self.redo)
        self.root.config(menu=menubar)

        """ DYNAMIC WINDOW RESIZE: """
        no_of_cols, no_of_rows = self.root.grid_size()
        for c in range(0, no_of_cols):
            self.root.grid_columnconfigure(c, weight=1)

        for r in range(0, no_of_rows):
            self.root.grid_rowconfigure(r, weight=1)

        self.help()  # So that the welcome page is displayed FIRST.
        self.root.mainloop()

    def graphIt(self, x_min=-5.0, x_max=5.0, y_min=-5.0, y_max=5.0, firstTime=True):
        """ MAIN INSTANCE VARIABLES: """

        if firstTime:  # If a brand new function is entered.
            self.original = str(self.function_entry.get())
            self.inputFunction = self.original
            self.x = 'x'
            self.y = 'y'
            self.ref_x = [None, None, None, None, None, None, None, None, None, None]
            self.ref_y = [None, None, None, None, None, None, None, None, None, None]

        try:
            assert self.original != '' and self.inputFunction != ''  # assert checks a condition; if False, it throws exception
        except Exception:  # This could either be AssertionError (assert is False) or AttributeError (self.original doesn't exist)
            messagebox.showerror(title="ERROR", message="Please enter a function!")
            return

        """ NOTE:
        These HAVE to come here, because they need come into existence ONLY when input has actually been entered.
        If it were defined in __init__(), original, for instance, is EMPTY (because nothing would be entered)!
        Therefore, they must be defined here, instead.
        Since they're instance variables, it doesn't matter anyway. They're accessible anywhere inside Session.
        """

        print(self.original)

        try:
            obj = FunctionGraph(
                original=self.original,
                f_of_x=self.inputFunction,
                x=self.x,
                y=self.y,
                x_min=x_min,
                x_max=x_max,
                y_min=y_min,
                y_max=y_max,
                ref_x=self.ref_x,
                ref_y=self.ref_y
            )
            img = obj.get_image()
        except BadParsing:
            messagebox.showerror(title='ERROR',
                                 message='INVALID FUNCTION!\nUsually, this occurs if you are attempting to enter a non-standard expression. Please make sure there are no errors in your entry, and try again. If you are seeing this error repeatedly, it is likely that your entered expression is not yet supported.')
            return
        except NoFunction:
            messagebox.showerror(title='ERROR', message='PLEASE ENTER A FUNCTION!')
            return
        except Exception:  # Generic exception--could be anything.
            messagebox.showerror(title='ERROR', message='INVALID')
            return

        savePath = './ImageRenderings/' + str(self.transformationNumber) + '.png'
        img.save(fp=savePath)
        print("Image saved")

        # img = Image.open(savePath)
        # windowwidth = self.root.winfo_width()
        # windowheight = self.root.winfo_height()
        # print("Window Size Obtained")
        newimg = img.resize(
            (int(img.size[0] * self.resize_amount),  # * windowwidth),
             int(img.size[1] * self.resize_amount))  # * windowheight))
        )  # The tuple must be (int, int)
        print("PIL.Image object resized")
        graphImg = ImageTk.PhotoImage(image=newimg)
        print("ImageTk.PhotoImage object initialized")

        self.graphLabel.configure(image=graphImg)  # Adds the image to the GUI dynamically... at least, it SHOULD...
        self.graphLabel.image = graphImg  # This is necessary, for some reason...
        print('Image (should be) added')

        self.renderings = self.renderings + [newimg]
        # Since renderings are always added at the END, all graphs are preserved.
        self.functionList = self.functionList + [self.inputFunction]
        self.xList = self.xList + [self.x]
        self.yList = self.yList + [self.y]
        self.refxlist = self.refxlist + [self.ref_x]
        self.refylist = self.refylist + [self.ref_y]
        # All these lists are so that a previous graph can still be transformed.
        self.transformationNumber = len(self.renderings)

        self.locationPlaceholderText = "Graph " + str(self.transformationNumber) + " of " + str(len(self.renderings))
        self.location.config(text=self.locationPlaceholderText)
        self.location.text = self.locationPlaceholderText

    def modifyGraphParameters(self):
        pi = np.pi
        e = np.e
        # Again, so that numexpr can recognize the symbols

        # ERROR HANDLING:

        try:
            if (self.entry_x_min.get() is None) or (self.entry_x_max.get() is None) or (self.entry_y_min.get() is None) or (self.entry_y_max.get() is None):
                raise NoGraphParameter

            xmin = float(ne.evaluate(str(self.entry_x_min.get())))
            xmax = float(ne.evaluate(str(self.entry_x_max.get())))
            ymin = float(ne.evaluate(str(self.entry_y_min.get())))
            ymax = float(ne.evaluate(str(self.entry_y_max.get())))

            assert (
                    xmin < xmax and
                    ymin < ymax
            )
        except AssertionError:
            messagebox.showerror(title='ERROR', message='The minimum value must be strictly less than the maximum value!')
            return
        except NoGraphParameter:
            messagebox.showerror(title='ERROR', message='Please ensure all parameters have been entered!')
            return
        except Exception:  # SyntaxError, ValueError, KeyError
            # Throws SyntaxError when numexpr is unable to evaluate.
            # Throws ValueError when float() fails
            messagebox.showerror(title='ERROR', message='Invalid Parameters!')
            return
        else:
            self.graphIt(
                x_min=xmin,
                x_max=xmax,
                y_min=ymin,
                y_max=ymax,
                firstTime=False
            )

    def transformIt(self, *options):
        pi = np.pi
        e = np.e

        selectedOption = str(self.placeholderText.get())
        which_t = str(selectedOption[0])
        transf = str(self.transformation_parameter.get())

        try:
            if which_t == 'S':
                raise InvalidTransformationOption
            elif transf == '':  # Using elif so that not selecting a transformation is given priority over not entering a parameter
                raise NoTransformationParameter
        except NoTransformationParameter:
            messagebox.showerror(title='ERROR', message='Please enter a parameter!')
            return
        except InvalidTransformationOption:
            messagebox.showerror(title='ERROR', message='Please select an option from 1 to 4!')
            return
        except Exception:  # Miscellaneous case
            messagebox.showerror(title='ERROR', message='Invalid Transformation!\nPlease recheck your entries.')
            return

        try:
            assert self.inputFunction != '' and self.original != ''
        except Exception:  # Again, it could still also be AttributeError, since there is no guarantee that firstTime is False. A user may have entered a transformation along with the new function.
            messagebox.showerror(title='ERROR', message='Please enter a function! If you have done so, please click \"GRAPH IT!\" to proceed.')
            return

        if which_t == '1':  # Replacing x for the label, and f for the numpy evaluation:
            self.x = self.x.replace('x', ('(x/(' + transf + '))'))
            self.inputFunction = self.inputFunction.replace('x', ('(x/(' + transf + '))'))
            for i in range(0, len(self.ref_x)):
                if not(self.ref_x[i] is None):
                    self.ref_x[i] = self.ref_x[i] * float(ne.evaluate(transf))
        elif which_t == '2':  # Replacing x for the label, and f for the numpy evaluation:
            self.x = self.x.replace('x', ('(x - (' + transf + '))'))
            self.inputFunction = self.inputFunction.replace('x', ('(x - (' + transf + '))'))
            for i in range(0, len(self.ref_x)):
                if not (self.ref_x[i] is None):
                    self.ref_x[i] = self.ref_x[i] + float(ne.evaluate(transf))
        elif which_t == '3':  # Replacing y for the label, and f for the numpy evaluation:
            self.y = self.y.replace('y', ('(y/(' + transf + '))'))
            self.inputFunction = '(' + transf + ') * (' + self.inputFunction + ')'
            for i in range(0, len(self.ref_y)):
                if not (self.ref_y[i] is None):
                    self.ref_y[i] = self.ref_y[i] * float(ne.evaluate(transf))
        elif which_t == '4':  # Replacing y for the label, and f for the numpy evaluation:
            self.y = self.y.replace('y', ('(y - (' + transf + '))'))
            self.inputFunction = self.inputFunction + ' + (' + transf + ')'
            for i in range(0, len(self.ref_y)):
                if not (self.ref_y[i] is None):
                    self.ref_y[i] = self.ref_y[i] + float(ne.evaluate(transf))

        self.graphIt(firstTime=False)

    def addRefPts(self):
        try:
            for i in range(0, 10):
                # For evaluation:
                pi = np.pi
                e = np.e

                assert not((self.refpts_entries['x'][i].get() != "" and str(self.refpts_entries['y'][i].get()) == "") \
                           or (self.refpts_entries['x'][i].get() == "" and self.refpts_entries['y'][i].get() != ""))

                if not(str(self.refpts_entries['x'][i].get()) == "") and not(str(self.refpts_entries['y'][i].get()) == ""):
                    self.ref_x[i] = float(ne.evaluate(str(self.refpts_entries['x'][i].get()).replace("^","**")))
                    self.ref_y[i] = float(ne.evaluate(str(self.refpts_entries['y'][i].get()).replace("^", "**")))

            assert len(self.ref_x) == len(self.ref_y)

        except AssertionError:
            messagebox.showerror(title="ERROR", message="Check to see that all reference points have both x and y coordinates!")
            return
        except Exception:
            messagebox.showerror(title="ERROR", message="Check your Reference Point syntax!")
            return

        print(self.ref_x, self.ref_y)

        self.graphIt(firstTime=False)

    def clearRefPts(self):
        self.ref_x = [None, None, None, None, None, None, None, None, None, None]
        self.ref_y = [None, None, None, None, None, None, None, None, None, None]
        self.graphIt(firstTime=False)

    def undo(self):
        try:
            assert self.transformationNumber > 1
        except AssertionError:
            messagebox.showerror(title='ERROR', message='No previous graph!')
        else:
            self.transformationNumber = self.transformationNumber - 1
            # Updating all instance variables so that it really gets undone
            graphImg = ImageTk.PhotoImage(
                image=self.renderings[self.transformationNumber - 1])
            self.x = self.xList[self.transformationNumber - 1]
            self.y = self.yList[self.transformationNumber - 1]
            self.inputFunction = self.functionList[self.transformationNumber - 1]
            self.ref_x = self.refxlist[self.transformationNumber - 1]
            self.ref_y = self.refylist[self.transformationNumber - 1]
            # [List indices begin at 0, while transformationNumber begins at 1]

            self.graphLabel.configure(image=graphImg)
            self.graphLabel.image = graphImg

            self.locationPlaceholderText = "Graph " + str(self.transformationNumber) + " of " + str(
                len(self.renderings))
            self.location.config(text=self.locationPlaceholderText)
            self.location.text = self.locationPlaceholderText

    def redo(self):
        try:
            assert self.transformationNumber < len(self.renderings)
        except AssertionError:
            messagebox.showerror(title='ERROR', message='No next graph!')
        else:
            graphImg = ImageTk.PhotoImage(
                image=self.renderings[self.transformationNumber])  # Cuz it's always 1 greater than current
            self.x = self.xList[self.transformationNumber]
            self.y = self.yList[self.transformationNumber]
            self.inputFunction = self.functionList[self.transformationNumber]

            self.graphLabel.configure(image=graphImg)
            self.graphLabel.image = graphImg
            self.transformationNumber = self.transformationNumber + 1

            self.locationPlaceholderText = "Graph " + str(self.transformationNumber) + " of " + str(
                len(self.renderings))
            self.location.config(text=self.locationPlaceholderText)
            self.location.text = self.locationPlaceholderText

    def help(self):
        helpwindow = Toplevel(self.root)  # , title='Welcome to Trans4m8!')
        helpwindow.attributes('-topmost', 'true')
        themessage = ttk.Label(helpwindow, wraplength=640, justify="left", text=
        """
        Always wanted a way to visualize consecutive transformations? Trans4m8 is JUST the thing for you!

        To enter a function, simply type it into the field and click on 'GRAPH IT!' Your graph should appear momentarily.

        Trans4m8 supports several kinds of functions: polynomial, trigonometric, exponential, logarithmic, hyperbolic and more. More complex functions, however, are not yet supported. Arbitrary constants, too, are not yet supported.

        Standard parsing conventions are used: for instance, to enter π, type "pi"; to enter the square root of an expression, type "sqrt(your expression)". When using other standard functions too, remember to enclose your argument in (parentheses).

        Trans4m8 also supports basic single-variable calculus: to graph a derivative, simply type diff(your function); for indefinite integrals (C=0), type integrate(integrand, x); for definite integrals, type integrate(integrand, (x, lower, upper)). 

        If you wish to adjust the parameters of the graph (say, if your desired graph is not visible in the current window), simply enter the new values for minimum and maximum x and y in the Graph Parameters pane. Ensure that you have entered values for ALL the fields. To apply, simply click on the button. Note: if you enter a decimal value, the limit is automatically shifted to the next integer value (the "ceil" of the maximum and the "floor" of the minimum).

        If you wish to transform your graph by stretching (scaling) or shifting (translating), simply select the option from the drop-down menu and enter the parameter in the field given. Note: if you wish to SHRINK your graph by some factor k, enter your scale factor as 1/k. Likewise, if you wish to translate in the negative direction (downwards or leftwards), enter a negative value.
        
        Sometimes, it's useful to have reference points to see how transformations affect points in space. To enter a reference point, simply enter your coordinates in the respective fields and click "ADD POINTS". They should appear momentarily on your graph, labelled (x1,y1) till (x10,y10) as per your entry. Reference points are subject to the same features as functions: if you perform a transformation, the points, under the same labels, are also transformed to new coordinates. To clear all points, hit the "CLEAR POINTS" button.

        If you wish to shift between graphs, use the 'Previous' and 'Next' buttons to navigate. Note: Even if you go back to a previous graph and adjust your transformation, it does not overwrite any of your other graphs. All your transformations are preserved until you close Trans4m8. This is particularly useful as an educational tool: if you wish to approach how successive transformations applied in different orders can lead to different graphs, this is the way to do so! 

        If you wish to see this text again, simply navigate to Trans4m8 ⟶ Help in the menu.

        Happy transforming!
        """
                           )
        themessage.pack()

    def about(self):
        aboutwindow = Toplevel(self.root)  # , title='About')
        aboutwindow.attributes('-topmost', 'true')
        themessage = ttk.Label(aboutwindow, wraplength=640, justify="left", text=
        """
        ACKNOWLEDGEMENTS:

        Trans4m8 was built on Python, and uses standard Python libraries such as SymPy, NumPy and NumExpr.

        All graphs are created using Manim, an open-source Python-based Math Animation software built by Grant Sanderson (YouTube: 3blue1brown).
        
        The developer behind Trans4m8 would like to acknowledge the contributions of his primary client, Ms. SA, a teacher of IB Mathematics, and his various β-testers, who were mainly high-school students. All your suggestions and feedback have proven invaluable, and have greatly enhanced the scope and appeal of this project.
        """
                           )
        themessage.pack()


# End

# Some Exceptions:

class NoGraphParameter(Exception):
    pass


class NoTransformationParameter(Exception):
    pass


class InvalidTransformationOption(Exception):
    pass