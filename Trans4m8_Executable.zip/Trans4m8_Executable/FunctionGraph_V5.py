#  Attempt to include Reference Points

import sympy as sp
from sympy.parsing.sympy_parser import standard_transformations, implicit_multiplication_application
import numexpr as ne
import manimlib
from manimlib.imports import *

from PIL import Image


class FunctionGraph(GraphScene):
    #CONFIG = {}  # All modifications are handled in __init__

    def __init__(self, original, f_of_x, x, y, x_min=-16, x_max=16, y_min=-12, y_max=12, ref_x=[], ref_y=[], *args, **kwargs):  # Specifying default values in case not explicitly defined

        self.x_min = int(np.floor(x_min))
        self.x_max = int(np.ceil(x_max))
        self.y_min = int(np.floor(y_min))
        self.y_max = int(np.ceil(y_max))

        self.ref_x = ref_x
        self.ref_y = ref_y

        x_step = int(np.ceil((self.x_max - self.x_min) / 10))
        y_step = int(np.ceil((self.y_max - self.y_min) / 8))

        self.x_labeled_nums = range(self.x_min, self.x_max + x_step, x_step)
        self.y_labeled_nums = range(self.y_min, self.y_max + y_step, y_step)

        self.original = original
        self.original = self.original.replace('^', '**')  # Since exponentiation is denoted by ** in Python syntax
        self.original = self.original.replace('exp', 'e**')  # Lest 'exp' be parsed as e * x * p for some constant p

        self.ip = f_of_x
        self.ip = self.ip.replace('^', '**')  # Since exponentiation is denoted by ** in Python syntax
        self.ip = self.ip.replace('exp', 'e**')  # Lest 'exp' be parsed as e * x * p for some constant p
        self.ip = self.ip.replace('d/dx', 'diff')

        self.y = y
        self.x = x

        self.graph_origin = (LEFT*((self.x_min + self.x_max)/2) / x_step) + (DOWN*((self.y_min + self.y_max)/2) / y_step)
        #self.graph_origin = ORIGIN

        super().__init__(**kwargs)

    def construct(self):
        # Parsing:

        function_body = parse(string=self.ip, eval=True)
        y_transformed = parse(string=self.y, eval=True)
        x_transformed = parse(string=self.x, eval=True)
        original_function = parse(string=self.original, eval=True)

        # Verifying the Parse:
        self.expr_tostring = str(function_body)
        print(self.expr_tostring)

        # Converting it to LaTeX (for labelling on the Graph):

        original_latex = str(sp.latex(original_function))
        y_latex = str(sp.latex(y_transformed))
        x_latex = str(sp.latex(x_transformed))

        # Just to verify...
        equation = sp.Eq(sp.symbols('y'), function_body)
        expr_latex = str(sp.latex(equation))
        s = str(expr_latex)
        print(s)

        graphLabel = y_latex + ' = f\\left(' + x_latex + '\\right)'

        # Displaying:

        self.setup_axes(animate=False)
        func_graph = self.get_graph(self.func_to_graph,
                                    x_max=self.x_max,
                                    x_min=self.x_min
                                    )
        graph_lab = self.get_graph_label(func_graph, label=graphLabel, x_val=5, direction=4*DOWN+1*RIGHT)
        #self.add(func_graph)
        #self.add(graph_lab)

        self.add(func_graph, graph_lab)
        #self.wait(2)

        print("ORIGINAL = \"" + original_latex + "\"")

        general_function = TexMobject('f\\left(x\\right) = ' + original_latex)
        general_function.to_corner(UP + LEFT)
        self.add(general_function)

        general_y = TexMobject(s)
        general_y.to_corner(DOWN + LEFT)
        self.add(general_y)

        # Adding Reference Points:

        points = []
        labels = []
        for i in range(0, 10):  # Just to initialize it all
            points = points + [Dot()]
            labels = labels + [TexMobject("\\left( x_{" + str(i + 1) + "}, y_{" + str(i + 1) + "} \\right)").scale(0.75)]

        for i in range(0, len(self.ref_x)):
            if not(self.ref_x[i] is None or self.ref_y[i] is None):
                points[i].move_to(self.coords_to_point(self.ref_x[i], self.ref_y[i]))
                self.add(points[i])
                print("Reference point " + str(i+1) + " (" + str(self.ref_x[i]) + "," + str(self.ref_y[i]) + ") added")
                labels[i].move_to(self.coords_to_point(self.ref_x[i], self.ref_y[i]) + 0.36*UP + 0.36*RIGHT)
                self.add(labels[i])
                print("Reference point " + str(i+1) + " (" + str(self.ref_x[i]) + "," + str(self.ref_y[i]) + ") labeled")

        self.wait(0)  # To make this an "animation"

        #self.get_image()
        #print(self.get_image())

    def func_to_graph(self, x):  # Parametrized function. Returned numpy expression will then be y(x).
        pi = np.pi
        e = np.e
        # ^ This is so that numexpr identifies what 'pi' and 'e' are.
        if self.expr_tostring=="":
            raise NoFunction
        try:
            y_as_np = ne.evaluate(self.expr_tostring)
            return y_as_np
        except Exception:
            raise BadParsing


def parse(string, eval):
    transformations = (standard_transformations + (implicit_multiplication_application,))
    if string=="":
        raise NoFunction
    try:
        sp_expression = sp.parsing.sympy_parser.parse_expr(string, evaluate=eval, transformations=transformations)
        return sp_expression
    except Exception:
        raise BadParsing


"""
# THIS CLASS CAN BE USED AS FOLLOWS:

sampleGraph = FunctionGraph(
    original='sin(x)',
    f_of_x='sin(x/(1/2))',  # Or whatever transformation is applied
    x='(x/(1/2))',
    y='y',
    #x_min=-2*np.pi,
    #m_max=2*np.pi,
    #y_min=-1,
    #y_max=1
)

# ^ This creates an object of the FunctionGraph class. To render this graph, the following code can be run:

sampleImage = sampleGraph.get_image()  # This is a PIL Image, so standard PIL functions apply
sampleImage.show()

# ^ This displays the entire animation as an image (the equivalent of the -s flag in terminal commands).
# To save the image, the following code can be run:

savePath = 'Renderings/'
sampleImage.save(savePath + 'I_GRAPHED_A_SINE_CURVE.png')
"""

"""
NOW TO HANDLE A FEW EXCEPTIONS:
"""

class BadParsing(Exception):
    pass

class NoFunction(Exception):
    pass

class InitError(Exception):  # Not really necessary
    pass