#! /bin/bash
./venv/bin/python ./__main__.py