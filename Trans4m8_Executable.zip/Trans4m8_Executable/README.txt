Welcome to Trans4m8 for Mac!

Trans4m8 is an educational tool designed using 3blue1brown's manim. Its purpose is to help teachers and students tackle the topic of consecutive graph transformations, covering scaling and translation in the positive and negative x and y directions. Trans4m8 is easy and intuitive to use.

+=========================+
|INSTALLATION INSTRUCTIONS|
+=========================+

Trans4m8 runs on Python 3.8, which can be downloaded online (https://www.python.org/downloads/release/python-387/) for free.

After you have successfully installed Python on your Mac, open a terminal at the folder "Trans4m8_Executable". You can do this by pressing control and clicking on the folder in Finder and then selecting "New Terminal at Folder".

[Alternatively, launch Terminal and type "cd" followed by any of the following:
- clicking and dragging the folder "Trans4m8_Executable" from Finder to the terminal window
- copying the folder "Trans4m8_Executable" (⌘C) and pasting it in your terminal window
- manually entering the file path
Your command should ultimately look like "cd /Some/Path/Trans4m8_Executable"]

After opening your terminal, your terminal prompt should show
YourUserName@Your-Macs-Name Trans4m8_Executable %

Enter the following commands:

chmod a+x ./Installation_Script.sh

This command will ensure that that the bash script in Installation_Script.sh is in an executable format. You will not get any output in the terminal; this is absolutely normal. This command is what makes the next command possible:

./Installation_Script.sh

This is the script that installs Trans4m8 and all the libraries it uses. Pay attention to your terminal window, because you may need to enter your password to authorize the installation. Ensure that you have a stable internet connection.

After that exhaustive installation, your computer should be ready to run Trans4m8!

+================+
|RUNNING TRANS4M8|
+================+

To run Trans4m8, all you will need to do is open a terminal in the "Trans4m8_Executable" directory and type

./Trans4m8.sh

or

./venv/bin/python ./__main__.py

and Trans4m8 should launch momentarily.